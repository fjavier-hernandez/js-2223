var articulos = document.getElementById("main");
var navegacion = document.getElementsByTagName("nav");

var enlaces = document.getElementsByTagName("a");
var enlacesMain = articulos.getElementsByTagName("a");

var menuArtistas = navegacion[0].firstElementChild.firstElementChild.nextElementSibling;
var primerParrafo = articulos.firstElementChild.nextElementSibling;
var textoDespuesEnlace = enlacesMain[0].parentNode.lastChild;

// Selectores CSS
var articulosCSS = document.querySelector("#main");
var navegacionCSS = document.querySelector("nav");

var enlacesCSS = document.querySelector("a");
var enlacesMainCSS = document.querySelector("#main a");

var menuArtistasCSS = document.querySelector("nav.group > ol > li + li");
var primerParrafoCSS = document.querySelector("#main > p");
var textoDespuesEnlaceCSS = document.querySelector("#main a").parentNode.lastChild;
